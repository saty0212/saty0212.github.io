ShivaReva Farmstay - One page website
Files:
- index.html
- styles.css
- script.js

Replace the placeholder images (Unsplash links) in index.html with your 8 photos.
To host on GitHub Pages: create a repo, push these files to the repo's root (or gh-pages branch) and enable GitHub Pages.
